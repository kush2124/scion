package com.example.sameerg2.sicon;


import android.bluetooth.BluetoothGattCharacteristic;
import android.util.Log;

/**
 * Created by k.pareek on 5/2/2017.
 */

public class ProfileData  {

    public static String getProfileData(BluetoothGattCharacteristic characteristic)
    {
        ServicesCharacterstics inst = ServicesCharacterstics.getInstance();
        String Uuid = characteristic.getUuid().toString();
        String data=null;
        if(inst.getUidFromCharacterstics("Heart Rate Measurment").equalsIgnoreCase(Uuid))
         {
                int flag = characteristic.getProperties();
                int format = -1;

                if((flag & 0x01)!=0)
                {
                     format = BluetoothGattCharacteristic.FORMAT_UINT16;
                }else{
                     format = BluetoothGattCharacteristic.FORMAT_UINT8;
                }

                final int heartRate = characteristic.getIntValue(format,1);
                data = String.valueOf(heartRate);
         }else {

             final byte[]  value  = characteristic.getValue();
             if(value!=null && value.length>0) {
                 Log.d("ProfileData","insideProfile");
                   final StringBuilder builder = new StringBuilder(value.length);
                   for(byte byteChar : value)
                         builder.append(String.format("%02X ", byteChar));
                    data = " "+ new String(value) + "\n" + builder.toString();
             }
        }

         return data;
    }
}
