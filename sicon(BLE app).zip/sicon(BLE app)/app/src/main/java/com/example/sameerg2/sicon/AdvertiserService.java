package com.example.sameerg2.sicon;

import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.Intent;
import android.content.IntentFilter;
import android.icu.text.LocaleDisplayNames;
import android.os.Binder;
import android.os.IBinder;
import android.os.ParcelUuid;
import android.util.Log;

import java.nio.charset.Charset;
import java.util.HashMap;
import java.util.logging.Handler;


/**
 * Created by sameer.g2 on 24-Apr-17.
 */

public class AdvertiserService extends Service {


    private String TAG =  AdvertiserService.class.getSimpleName();
    private final IBinder mBinder = new LocalBinder();
    public static final String ACTION_ADV_SUCCESS = "com.example.sameerg2.sicon.ADV_SUCCESS";
    public static final String ACTION_ADV_FALIURE = "com.example.sameerg2.sicon.ADV_FALIURE";
    public static final String EXTRA_DATA = "com.example.sameerg2.sicon.EXTRA_DATA";
    public static final String ERROR_CODE = "com.example.sameerg2.sicon.ERROR_CODE";

    private HashMap<Integer,Thread> finalThreadMap;
    private HashMap<Integer,BluetoothLeAdvertiser> finalAdvertiser;
    private HashMap<Integer,AdvertiseCallback> finalCallbacks;
    @Override
    public void onCreate() {
        finalThreadMap = new HashMap<Integer,Thread>();
        finalAdvertiser = new HashMap<Integer, BluetoothLeAdvertiser>();
        finalCallbacks = new HashMap<Integer, AdvertiseCallback>();
        Log.d(TAG, "onCreate called");
    }

    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind done");
        return mBinder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        return false;
    }

    public class LocalBinder extends Binder {
        AdvertiserService getService() {
            // Return this instance of LocalService so clients can call public methods
            return AdvertiserService.this;
        }
    }




    /** methods */

    public int startAdvertisment(final AdvertisementPacket Adp){

        Log.d(TAG,Adp.getUniqueId()+" -- ");

        final BluetoothLeAdvertiser mLeAdvertiser = BluetoothAdapter.getDefaultAdapter().getBluetoothLeAdvertiser();

        finalAdvertiser.put(Adp.getUniqueId(),mLeAdvertiser);

        final Thread mThread = new Thread(new Runnable() {
            @Override
            public void run() {

                AdvertiseCallback advertisingCallback = new AdvertiseCallback() {
                    @Override
                    public void onStartSuccess(AdvertiseSettings settingsInEffect) {
                        Log.d( TAG, "Advertising onStartSuccess: ");
                        Intent i = new Intent();
                        i.setAction(ACTION_ADV_SUCCESS );
                        i.putExtra(EXTRA_DATA,Adp.getUniqueId());
                        sendBroadcast(i);

                        super.onStartSuccess(settingsInEffect);
                    }

                    @Override
                    public void onStartFailure(int errorCode) {

                        Intent i = new Intent();
                        i.setAction(ACTION_ADV_FALIURE );
                        i.putExtra(ERROR_CODE,errorCode);
                        i.putExtra(EXTRA_DATA,Adp.getUniqueId());
                        sendBroadcast(i);

                        Log.e( TAG, "Advertising onStartFailure: " + errorCode );
                        super.onStartFailure(errorCode);
                    }
                };

                finalCallbacks.put(Adp.getUniqueId(),advertisingCallback);
                AdvertiseData data = new AdvertiseData.Builder()
                                    .setIncludeDeviceName( Adp.getLocalName() )
                                    .addServiceUuid(ParcelUuid.fromString(Adp.getServiceUuid()))
                                    .addServiceData(ParcelUuid.fromString(Adp.getServiceUuid()), Adp.getServiceData().getBytes())
                                    .build();


                AdvertiseSettings settings = new AdvertiseSettings.Builder()
                        .setAdvertiseMode( Adp.getAdvMode() )
                        .setTxPowerLevel( Adp.getAdvPower() )
                        .setConnectable(Adp.getConnectable()) // cos GAP in not connectable service
                        .setTimeout(Adp.getTimeout()) // subjectable to change
                        .build();

                mLeAdvertiser.startAdvertising(settings,data,advertisingCallback);



            }
        });

        finalThreadMap.put(Adp.getUniqueId(),mThread);
        mThread.start();


        return 0;

    }


    public void stopAdvertising(final Integer Uid)
    {
        BluetoothLeAdvertiser mLeAdvertiser =  finalAdvertiser.get(Uid);
        Thread mThread = finalThreadMap.get(Uid);
        AdvertiseCallback advertiseCallback = finalCallbacks.get(Uid);

        if(mThread!= null && mThread.isAlive())
       {
            mThread.interrupt();

       }

        finalThreadMap.remove(Uid);

        Log.d(TAG,"stop");
        if(mLeAdvertiser!=null)
           mLeAdvertiser.stopAdvertising(advertiseCallback);
        finalCallbacks.remove(Uid);
        finalAdvertiser.remove(Uid);
    }

    public void removeThread(Integer Uid){
        finalThreadMap.remove(Uid);
    }






}