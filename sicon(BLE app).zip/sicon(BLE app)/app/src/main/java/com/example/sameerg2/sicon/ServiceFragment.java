package com.example.sameerg2.sicon;

import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;


/**
 * Created by k.pareek on 3/31/2017.
 */

@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
public class ServiceFragment extends Fragment {


      private static final String TAG = ServiceFragment.class.getSimpleName();

      public static final String BT_DEVICE ="com.example.kpareek.ble_client.BT_DEVICE";
      private BluetoothDevice device;
      private BluetoothLeService mService;
      private boolean mbound = false;
      private ArrayList<BluetoothGattService> expandListTitle;
      private HashMap<BluetoothGattService,List<BluetoothGattCharacteristic>> expandListDetail;
      private CustomAdapter expandableListAdapter;
      private ArrayList<BluetoothGattService>  vbServices;
      private IntentFilter filter;
      private ExpandableListView exp;
      private TextView infoView;
      private String title;
      private HashMap<UUID,Boolean> mEnabled;

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        Log.i("Test","OnAttach");
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.i("Test","OnCreate");
        //setRetainInstance(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        Log.i("Test","OnCreateView");
        View v = inflater.inflate(R.layout.service_fragment_view,container,false);
        exp = (ExpandableListView) v.findViewById(R.id.expand);
        infoView = (TextView) v.findViewById(R.id.info);
        device = getArguments().getParcelable(BT_DEVICE);

        expandListDetail = new HashMap<BluetoothGattService, List<BluetoothGattCharacteristic>>();
        expandListTitle = new ArrayList<BluetoothGattService>();
        expandableListAdapter = new CustomAdapter(getActivity(),expandListTitle,expandListDetail);
        exp.setAdapter(expandableListAdapter);


        mEnabled =  new HashMap<UUID, Boolean>();
        Intent intent = new Intent(getActivity(),BluetoothLeService.class);
        getActivity().getApplicationContext().bindService(intent,mConnection, Context.BIND_AUTO_CREATE);
        filter  = new IntentFilter();
        filter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        filter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        filter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        filter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        filter.addAction(BluetoothLeService.ACTION_DATA_CHANGED);
        filter.addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED);
        getActivity().registerReceiver(mBroadcastReciever,filter);




        exp.setOnGroupExpandListener(new ExpandableListView.OnGroupExpandListener() {


            @Override
            public void onGroupExpand(int groupPosition) {
                BluetoothGattService service = expandListTitle.get(groupPosition);
                Log.i(TAG,service.getUuid().toString()+"  "+"Type "+service.getType());
            }
        });

        exp.setOnGroupCollapseListener(new ExpandableListView.OnGroupCollapseListener() {
            @Override
            public void onGroupCollapse(int groupPosition) {
                infoView.setVisibility(View.INVISIBLE);
            }
        });

        exp.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                BluetoothGattService service = expandListTitle.get(groupPosition);
                BluetoothGattCharacteristic charer = expandListDetail.get(service).get(childPosition);

               if(mEnabled.get(charer.getUuid())!=null && mEnabled.get(charer.getUuid())==false) {
                    mEnabled.put(charer.getUuid(),true);
                    mService.enableNotification(charer, true);
               }
                Log.i(TAG,"Trying to read characterstic data");
                mService.readData(charer);
                Log.i(TAG,charer.getUuid().toString());
                return false;
            }
        });
        return v;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        Log.i("Test","OnAccreated");
        super.onActivityCreated(savedInstanceState);

    }


    public static ServiceFragment newInstance(BluetoothDevice device)
      {
          Bundle args = new Bundle();
          args.putParcelable(BT_DEVICE,device);
          ServiceFragment frag = new ServiceFragment();
          frag.setArguments(args);
          return frag;
      }

    @Override
    public void onStart() {
        super.onStart();
        Log.i("Test","Onstart");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.i("Test","OnResume");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.i("Test","OnPause");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.i("Test","OnStop");
    }

    @Override
    public void onDestroyView() {
        Log.i("Test","OnDesV");
        super.onDestroyView();
        try {
            getActivity().unregisterReceiver(mBroadcastReciever);
            if (mbound == true) {
                mService.disconnect();
                getActivity().getApplicationContext().unbindService(mConnection);

                Log.i(TAG, "Service Unbinded");
            }
        }catch (Exception e)
        {
            Log.e(TAG," "+e.getMessage());
        }

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i("Test","Ondestroy");
    }


    @Override
    public void onDetach() {
        super.onDetach();
        Log.i("Test","OnDeAttach");
    }

    public void clearUI()
    {
        expandListDetail.clear();
        expandListTitle.clear();
        expandableListAdapter.notifyDataSetChanged();
    }

    private BroadcastReceiver mBroadcastReciever  = new BroadcastReceiver(){

        @Override
        public void onReceive(Context context, Intent intent) {

            final String action = intent.getAction();
            if(BluetoothLeService.ACTION_GATT_CONNECTED.equals(action))
            {
                  Log.i(TAG,"connected to device");
            }
            else if(BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action))
            {
                  Log.i(TAG,"Disconnected from device");
                  clearUI();
                  exp.setVisibility(View.INVISIBLE);
                  infoView.setVisibility(View.VISIBLE);
                  infoView.setText("unable To connect");
            }
            else if(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action))
            {
                  Log.i(TAG,"ServicesDiscovered");


                  vbServices =  (ArrayList<BluetoothGattService>)mService.getSupportedServices();


                  clearUI();

                  if(vbServices!=null) {
                      infoView.setVisibility(View.INVISIBLE);
                      for (BluetoothGattService x : vbServices) {
                          expandListDetail.put(x, x.getCharacteristics());
                          expandListTitle.add(x);
                      }


                      ((CustomAdapter) expandableListAdapter).notifyDataSetChanged();
                  }else{
                      infoView.setText("No services Found");
                  }


            }
            else if(BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action))
            {

                String data = intent.getStringExtra(BluetoothLeService.EXTRA_DATA);
                infoView.setVisibility(View.VISIBLE);
                infoView.setText(data);
                Log.i(TAG,"Data Available"+" "+data);



            }
            else if(BluetoothLeService.ACTION_DATA_CHANGED.equals(action))
            {

                String data = intent.getStringExtra(BluetoothLeService.EXTRA_DATA);
                infoView.setVisibility(View.VISIBLE);
                infoView.setText(data);
                Log.i(TAG,"Data Changed"+" "+data);

            }

            else if(BluetoothDevice.ACTION_BOND_STATE_CHANGED.equals(action))
            {
                BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                if(device.getBondState()==BluetoothDevice.BOND_NONE)
                {
                    Log.i(TAG,"UnBonded");
                }else if(device.getBondState()==BluetoothDevice.BOND_BONDING)
                {
                    Log.i(TAG,"Pairing");
                }else{
                    Log.i(TAG,"BONDED");

                    mService.connect(device);

                }

            }

        }
    };




      private ServiceConnection mConnection = new ServiceConnection() {
          @Override
          public void onServiceConnected(ComponentName name, IBinder service) {
              BluetoothLeService.LeBinder binder = (BluetoothLeService.LeBinder) service;
              mService = ((BluetoothLeService.LeBinder) service).getService();
              Log.i(TAG,"Connecting to device");
              mService.connect(device);
              mbound=true;
          }

          @Override
          public void onServiceDisconnected(ComponentName name) {
              mbound=false;
          }
      };


}
