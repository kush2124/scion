package com.example.sameerg2.sicon;

import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.content.Context;
import android.graphics.Typeface;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.TextView;
import java.util.HashMap;
import java.util.List;

/**
 * Created by k.pareek on 3/23/2017.
 */
@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)


public class CustomAdapter extends BaseExpandableListAdapter {

    private Context context;
    private List<BluetoothGattService> expandableListTitle;
    private HashMap<BluetoothGattService,List<BluetoothGattCharacteristic>> expandableListDetail;



    public CustomAdapter(Context con, List<BluetoothGattService> title, HashMap<BluetoothGattService,List<BluetoothGattCharacteristic>> detail)
    {
        context = con;
        expandableListTitle=title;
        expandableListDetail = detail;
    }
    @Override
    public int getGroupCount() {
        return expandableListTitle.size();
    }

    @Override
    public int getChildrenCount(int groupPosition) {
        return expandableListDetail.get(expandableListTitle.get(groupPosition)).size();
    }

    @Override
    public Object getGroup(int groupPosition) {
        return expandableListTitle.get(groupPosition);
    }

    @Override
    public Object getChild(int groupPosition, int childPosition) {
        return expandableListDetail.get(expandableListTitle.get(groupPosition)).get(childPosition);
    }

    @Override
    public long getGroupId(int groupPosition) {
        return groupPosition;
    }

    @Override
    public long getChildId(int groupPosition, int childPosition) {
        return childPosition;
    }

    @Override
    public boolean hasStableIds() {
        return false;
    }


    private String convert(String uuid)
    {
        String newUuid="";
        char[] chars = uuid.toCharArray();
        for(int i = 0;i<chars.length;i++)
        {
            if(chars[i]!='-')
            {
                newUuid += chars[i];
            }
        }

        return newUuid;
    }
    @Override
    public View getGroupView(int groupPosition, boolean isExpanded, View convertView, ViewGroup parent) {

        BluetoothGattService service = (BluetoothGattService) getGroup(groupPosition);
        if(convertView==null)
        {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.list_group,parent,false);

        }
        TextView listText = (TextView) convertView.findViewById(R.id.uuid_service);

        String text = (ServicesCharacterstics.getInstance()).getServiceFromUUID(service.getUuid().toString().toUpperCase());

        if(text==null)text = convertView.getResources().getString(R.string.unknown_service);
        listText.setText(text);
        listText.setTypeface(null, Typeface.BOLD);
        return convertView;
    }

    @Override
    public View getChildView(int groupPosition, int childPosition, boolean isLastChild, View convertView, ViewGroup parent) {

        BluetoothGattCharacteristic detail = (BluetoothGattCharacteristic) getChild(groupPosition,childPosition);
        if(convertView==null)
        {
            LayoutInflater layoutInflater = (LayoutInflater) this.context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflater.inflate(R.layout.list_item,parent,false);

        }

        String text = ServicesCharacterstics.getInstance().getcharFromUuid(detail.getUuid().toString().toUpperCase());
        if(text==null)text = "Unknown characterstic";
        TextView listText = (TextView) convertView.findViewById(R.id.uuid_char);
        listText.setText(text);
        return convertView;
    }

    @Override
    public boolean isChildSelectable(int groupPosition, int childPosition) {
        return true;
    }
}
