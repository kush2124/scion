package com.example.sameerg2.sicon;


import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanFilter;
import android.bluetooth.le.ScanResult;
import android.bluetooth.le.ScanSettings;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.ParcelUuid;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sameerg2.sicon.ServicesCharacterstics;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.logging.Filter;


/**
 * Created by k.pareek on 3/30/2017.
 */

@RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)

public class ScannerFragment extends ListFragment {

    private final static String TAG = ScannerFragment.class.getSimpleName();
    private static final int REQUEST_ENABLE_BT = 1;
    private ArrayList<BluetoothDevice> leDevices = new ArrayList<BluetoothDevice>();
    private ArrayList<String> devAdd = new ArrayList<String>();
    private BluetoothAdapter mBluetoothAdapter;
    private boolean mScanning;
    private Handler mHandler;
    private BluetoothLeScanner mScanner;
    private static final long SCAN_PERIOD = 20000;
    private ScanSettings settings;
    private List<ScanFilter> filters;
    private final int REQUEST_VALUES = 0;
    private final static  String DIALOG = "dialog";
    private int LOW_RSSI  =  0;
    private int MID_RSSI  =  1;
    private int HIGH_RSSI =  2;
    private int scanMode;
    private int rssiMode;
    private String serviceName;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        setRetainInstance(true);
        setModes(null,0,2);
        Log.d(TAG,"OnCreate");
        LeScanAdapter adapter = new LeScanAdapter(leDevices);
        setListAdapter(adapter);
        mHandler=new Handler();
        final BluetoothManager mBluetoothManager = (BluetoothManager) getActivity().getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = mBluetoothManager.getAdapter();

    }

    private void setModes(String service,int rssi,int power)
    {

        scanMode = power;
        rssiMode = rssi;
        if(service==null) serviceName=null;
        else {
            serviceName = ServicesCharacterstics.getInstance().getServiceUUID(service);
        }
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==REQUEST_VALUES)
        {
            if(resultCode==Activity.RESULT_CANCELED)return;
            else {
                int mode       = data.getIntExtra(FilterFragment.EXTRA_POWER,ScanSettings.SCAN_MODE_LOW_LATENCY);
                int rssi       = data.getIntExtra(FilterFragment.EXTRA_RSSI,LOW_RSSI);
                String service = data.getStringExtra(FilterFragment.EXTRA_SERVICE);
                Log.d("MODES","mode "+mode+" rssi "+rssi+" service "+service);
                setModes(service,rssi,mode);
            }


        }
        else if (requestCode == REQUEST_ENABLE_BT) {
            if (resultCode == Activity.RESULT_CANCELED) {
                getActivity().finish();
                return;
            }
        }

        getScanner();
        clearList();
        scanDevices(true);
    }
    public void clearList()
    {
        leDevices.clear();
        devAdd.clear();
        ((LeScanAdapter)getListAdapter()).notifyDataSetChanged();
    }

    public void getScanner()
    {

        //Log.d("Scanner","Inside Scanner");
        if(mScanner==null) {
            mScanner = mBluetoothAdapter.getBluetoothLeScanner();
        }
        settings = new ScanSettings.Builder()
                .setScanMode(scanMode)
                .build();
        filters = new ArrayList<ScanFilter>();
        //Log.d("NAME"," "+serviceName);
        if(serviceName!=null) {
            ScanFilter filter = new ScanFilter.Builder().setServiceUuid(ParcelUuid.fromString(serviceName))
                    .build();
            Log.d("TEST"," "+ParcelUuid.fromString(serviceName));
            filters.add(filter);
        }

    }
    @Override
    public void onResume() {
        super.onResume();
        if (mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled()) {
            Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
        }else {
            getScanner();
            clearList();
            scanDevices(true);
        }
    }



    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mBluetoothAdapter != null && mBluetoothAdapter.isEnabled()) {
            scanDevices(false);
        }

    }


    private void scanDevices(boolean enable)
    {
        if(enable)
        {
            mHandler.postDelayed(new Runnable() {

                @Override
                public void run() {
                    mScanning=false;
                    mScanner.stopScan(mScanCallback);
                    mScanner.flushPendingScanResults(mScanCallback);
                }
            },SCAN_PERIOD);


            mScanning=true;
            if(mScanner!=null)
                mScanner.startScan(filters,settings,mScanCallback);
        }
        else
        {
            mScanning=false;
            mScanner.stopScan(mScanCallback);
        }

    }

    private ScanCallback mScanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            Log.i(TAG, String.valueOf(callbackType));
            Log.i(TAG, result.toString());
            final BluetoothDevice btDevice = result.getDevice();

            if(devAdd.contains(btDevice.getAddress())==false)
            {
                leDevices.add(btDevice);
                devAdd.add(btDevice.getAddress());
                ((LeScanAdapter)getListAdapter()).notifyDataSetChanged();
            }



        }


        @Override
        public void onBatchScanResults(List<ScanResult> results) {
            for (ScanResult sr : results) {
                Log.i(TAG,"Inside batchScan");
                Log.i(TAG, sr.toString());
            }
        }

        @Override
        public void onScanFailed(int errorCode) {
            Log.e(TAG , " "+errorCode);
        }
    };


    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {

        if(mBluetoothAdapter!=null && mBluetoothAdapter.isEnabled()) {
            super.onListItemClick(l, v, position, id);
            Log.d(TAG, "item clicked " + position);
            BluetoothDevice device = (BluetoothDevice) getListAdapter().getItem(position);
            scanDevices(false);
            if (device == null) getActivity().finish();
            Log.d(TAG, device.getAddress());
            Intent intent = new Intent(getActivity(), ServiceDisplay.class);
            intent.putExtra(ServiceDisplay.DEVICE, device);
            startActivity(intent);





        }
        else
        {
            Toast.makeText(getActivity(), "R.string.notAvailable", Toast.LENGTH_SHORT).show();
            getActivity().finish();
        }

    }


    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        inflater.inflate(R.menu.items,menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        getScanner();
        super.onOptionsItemSelected(item);
        switch (item.getItemId())
        {

            case R.id.scan:
                clearList();
                if(mScanning==true) {
                    scanDevices(false);
                }
                scanDevices(true);
                break;
            case R.id.stopScan:
                if(mScanning==true) {
                    scanDevices(false);
                }
                break;
            case R.id.filter:
                if(mScanning==true)scanDevices(false);

                FragmentManager fm = getActivity().getSupportFragmentManager();
                FilterFragment dialog = FilterFragment.newInstance(serviceName,rssiMode,scanMode);
                dialog.setTargetFragment(ScannerFragment.this,REQUEST_VALUES);
                dialog.show(fm,DIALOG);

        }

        return true;
    }

    private class LeScanAdapter extends ArrayAdapter<BluetoothDevice>
    {
        public LeScanAdapter(ArrayList<BluetoothDevice>leDevices)
        {
            super(getActivity(),0,leDevices);
        }

        public View getView(int position, View convertView, ViewGroup parent)
        {
            ViewHolder holder;
            if(convertView==null)
            {
                convertView = getActivity().getLayoutInflater().inflate(R.layout.le_devices,null);
                TextView nameTextView =  (TextView)convertView.findViewById(R.id.device_name);
                TextView addTextView = (TextView) convertView.findViewById(R.id.device_add);

                holder = new ViewHolder(nameTextView,addTextView);
                convertView.setTag(holder);
            }


            holder = (ViewHolder) convertView.getTag();
            BluetoothDevice device = getItem(position);
            if(device.getName()!=null)
                holder.getNameTextView().setText(device.getName());
            else
                holder.getNameTextView().setText(getResources().getString(R.string.unknown_device));

            holder.getAddTextView().setText(device.getAddress());

            return  convertView;
        }



    }
}
class ViewHolder{


    TextView nameTextView;
    TextView addTextView;



    public ViewHolder(TextView name,TextView add)
    {
        nameTextView =name;
        addTextView  =add;

    }

    public TextView getNameTextView()
    {
        return nameTextView;
    }
    public TextView getAddTextView()
    {
        return addTextView;
    }

}
