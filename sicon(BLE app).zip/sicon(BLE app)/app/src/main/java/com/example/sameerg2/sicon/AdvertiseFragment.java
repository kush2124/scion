package com.example.sameerg2.sicon;

import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.ListFragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.HashMap;


public class AdvertiseFragment extends ListFragment {

    private static final String TAG = AdvertiseFragment.class.getSimpleName();

    private AdvertiserService mService;
    private boolean mBound = false;
    private Dialog newAdvDialog=null;
    private static int instanceVar =0;

    private HashMap<Integer,AdvertisementPacket> advInfo;
    private ArrayList<AdvertisementPacket> packetList;
    private IntentFilter intentFilter = new IntentFilter();
    
    private EditText displayName,serviceUuid,serviceData,timeVal;
    private CheckBox localName,connectable,timeCheck;
    private Spinner advPower, advMode;
    private Button dialogOK, dialogCancel;
    private HashMap<Integer,Switch> switchHashMap;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        Log.d(TAG,"oncv");
        setRetainInstance(true);
        FrameLayout rootView = (FrameLayout)inflater.inflate(R.layout.fragment_advertise, container, false);

        advInfo = new HashMap<Integer,AdvertisementPacket>();
        packetList = new ArrayList<AdvertisementPacket>();
        switchHashMap = new HashMap<Integer,Switch>();

        AdvertiseAdapter adapter = new AdvertiseAdapter(packetList);
        setListAdapter(adapter);



         Intent i= new Intent(getActivity(), AdvertiserService.class);
         i.putExtra("KEY1", "Value to be used by the service");//purpose
         getActivity().getApplicationContext().bindService(i, mConnection, Context.BIND_AUTO_CREATE);

         intentFilter.addAction(AdvertiserService.ACTION_ADV_FALIURE);
         intentFilter.addAction(AdvertiserService.ACTION_ADV_SUCCESS);
         getContext().registerReceiver(mBroadcastReciever,intentFilter);

         Log.d(TAG,"Create AF");

         setupUI(rootView);



        return rootView;
    }

    @Override
    public void onDestroyView() {

        Log.d(TAG,"Destroy AF");


        getActivity().unregisterReceiver(mBroadcastReciever);
        if(mService!=null && mConnection!=null && mBound){

            getActivity().getApplicationContext().unbindService(mConnection);
        }
        super.onDestroyView();
    }




    private void setupUI(FrameLayout rootView){

        newAdvDialog = new Dialog(getContext());
        newAdvDialog.setContentView(R.layout.advertising_packet);

        displayName = (EditText)newAdvDialog.findViewById(R.id.input_name);
        serviceUuid = (EditText)newAdvDialog.findViewById(R.id.Suuid);
        serviceData = (EditText)newAdvDialog.findViewById(R.id.Sdata);

        localName = (CheckBox)newAdvDialog.findViewById(R.id.Lname);
        connectable = (CheckBox)newAdvDialog.findViewById(R.id.connectable);



        advMode = (Spinner)newAdvDialog.findViewById(R.id.spinner_Advmode);
        advPower = (Spinner)newAdvDialog.findViewById(R.id.spinner_AdvPower);

        dialogOK = (Button)newAdvDialog.findViewById(R.id.dialog_ok);
        dialogCancel = (Button)newAdvDialog.findViewById(R.id.dialog_cancel);

        dialogCancel.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                newAdvDialog.dismiss();
                refreshDialog();
            }
        });


        dialogOK.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(displayName.getText().toString().trim().equals("")) {
                    Toast.makeText(getContext(), "Display name is mandatory", Toast.LENGTH_SHORT).show();
                }
                else if(serviceUuid.getText().toString().trim().equals("") || serviceData.getText().toString().trim().equals(""))
                    Toast.makeText(getContext(),"Service UUID and Data is mandatory",Toast.LENGTH_SHORT).show();
                else{
                    AdvertisementPacket adPacket = getData();
                    advInfo.put(adPacket.getUniqueId(),adPacket);
                    packetList.add(adPacket);
                    Log.d(TAG,"dailoge"+adPacket.getUniqueId());
                    ((AdvertiseAdapter)getListAdapter()).notifyDataSetChanged();
                   // startAdvertisement(adPacket);
                    newAdvDialog.dismiss();
                    refreshDialog();
                }

            }
        });


        FloatingActionButton fButton = (FloatingActionButton) rootView.findViewById(R.id.floatingActionButton);
        fButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newAdvDialog.show();
                displayName.requestFocus();
            }
        });

    }

    private void refreshDialog(){
        localName.setChecked(false);
        connectable.setChecked(false);


        displayName.setText("");
        serviceUuid.setText(getString(R.string.tempUUID));
        serviceData.setText("");

        advMode.setSelection(0);
        advPower.setSelection(0);
    }

    private AdvertisementPacket getData(){

        String dName = displayName.getText().toString().trim();
        String sUuid = serviceUuid.getText().toString().trim();
        String sData = serviceData.getText().toString().trim();

        Boolean lName = false;
        if(localName.isChecked()==true){
            lName = true;
        }
        Boolean conn = false;
        if(localName.isChecked()==true){
            conn = true;
        }

        int advModeint =  advMode.getSelectedItemPosition();
        int advPowerint = advPower.getSelectedItemPosition();

        instanceVar++;

        Log.d(TAG,advModeint + " = "+advPowerint);
        AdvertisementPacket finalAdvPacket = new AdvertisementPacket
                        (dName,sUuid,sData,lName,conn,advModeint,advPowerint,instanceVar,0);

        return finalAdvPacket;

    }


    private void startAdvertisement (AdvertisementPacket ADPacket){
        Log.d(TAG,"st adv");
        mService.startAdvertisment(ADPacket);
    }

    private void stopAdvertisment(Integer Uid)
    {
        mService.stopAdvertising(Uid);
    }

    private BroadcastReceiver mBroadcastReciever  = new BroadcastReceiver(){

        @Override
        public void onReceive(Context context, Intent intent) {

            final String action = intent.getAction();
            final int Uid = intent.getIntExtra(AdvertiserService.EXTRA_DATA,-1);

            if(AdvertiserService.ACTION_ADV_SUCCESS.equals(action)){
                Toast.makeText(getContext(),advInfo.get(Uid).getDisplayName()+" successfully advertising",Toast.LENGTH_SHORT).show();
            }
            if(AdvertiserService.ACTION_ADV_FALIURE.equals(action)){
                int i = intent.getIntExtra(AdvertiserService.ERROR_CODE,-1);
                Toast.makeText(getContext(),advInfo.get(Uid).getDisplayName()+" : "+getErrorReason(i),Toast.LENGTH_SHORT).show();
                packetList.remove(  advInfo.get(Uid));
                advInfo.remove(Uid);
                ((AdvertiseAdapter)getListAdapter()).notifyDataSetChanged();
                mService.removeThread(Uid);
            }

        }
    };


    private String getErrorReason(int i){

        if(i==1){
            return "Failed to start advertising as the advertise data to be broadcasted is larger than 31 bytes.";
        }
        if(i==2){
            return "Failed to start advertising because no advertising instance is available.";
        }
        if(i==3){
            return "Failed to start advertising as the advertising is already started.";
        }
        if(i==4){
            return "Operation failed due to an internal error.";
        }
        if(i==5){
            return "This feature is not supported on this platform.";
        }

        return "Operation failed due to an internal error.";

    }


    private ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName className, IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            AdvertiserService.LocalBinder binder = (AdvertiserService.LocalBinder) service;
            mService = binder.getService();
            mBound = true;
            Log.d(TAG," service connected");
        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
            Log.d(TAG," service not connected");
        }
    };

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
            AdvertisementPacket tempPacket= ((AdvertiseAdapter)getListAdapter()).getItem(position);
            fillADVData(tempPacket);
    }

    public void fillADVData(AdvertisementPacket packet){

        Dialog DispAdvDialog = new Dialog(getContext());
        DispAdvDialog.setContentView(R.layout.advertismentpacketdisplay);

        TextView name = (TextView)DispAdvDialog.findViewById(R.id.DispName);
        TextView uid = (TextView)DispAdvDialog.findViewById(R.id.DispUid);
        TextView suuid = (TextView)DispAdvDialog.findViewById(R.id.DispSuuid);
        TextView sdata = (TextView)DispAdvDialog.findViewById(R.id.DispSdata);
        TextView Amode = (TextView)DispAdvDialog.findViewById(R.id.DispAmode);
        TextView Apower = (TextView)DispAdvDialog.findViewById(R.id.DispApower);
        TextView Lname = (TextView)DispAdvDialog.findViewById(R.id.DispLname);
        TextView Conn = (TextView)DispAdvDialog.findViewById(R.id.DispConn);
        TextView Time = (TextView)DispAdvDialog.findViewById(R.id.DispTime);

        name.setText(packet.getDisplayName());
        uid.setText(packet.getUniqueId().toString());
        suuid.setText(packet.getServiceUuid());
        sdata.setText(packet.getServiceData());

        String[] TestArray1 =  getResources().getStringArray(R.array.Advpower_array);
        Apower.setText(TestArray1[packet.getAdvPower()]);

        String[] TestArray2 =  getResources().getStringArray(R.array.Advmode_array);
        Amode.setText(TestArray2[packet.getAdvMode()]);

        Boolean Ln = packet.getLocalName();
        if(Ln==true){
            Lname.setText("True");
        }
        else{
            Lname.setText("False");
        }

        Boolean co = packet.getConnectable();
        if(co==true){
            Conn.setText("True");
        }
        else{
            Conn.setText("False");
        }

        int ti = packet.getTimeout();
        if(ti == 0){
            Time.setText("Indefinitily");
        }
        else{
            Time.setText(ti+" ms");
        }

        DispAdvDialog.show();
    }


    private class AdvertiseAdapter extends ArrayAdapter<AdvertisementPacket>{

        public AdvertiseAdapter(ArrayList<AdvertisementPacket> packet) {
            super(getActivity(),0, packet);
        }

        public View getView(final int position, View convertView, ViewGroup parent) {

            final AdvertisementPacket packet = (AdvertisementPacket) getListAdapter().getItem(position);
            Log.d(TAG,"List adapter Position  - >"+position);
            convertView = getActivity().getLayoutInflater().inflate(R.layout.advertismentlayout,parent,false);
            TextView adName =  (TextView)convertView.findViewById(R.id.AdvPacketName);
            adName.setText(packet.getDisplayName());
            TextView adUid =  (TextView)convertView.findViewById(R.id.AdvPacketUid);
            adUid.setText(packet.getUniqueId().toString());
            Switch adSwitch =  (Switch)convertView.findViewById(R.id.ADswitch);

            adSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if(isChecked){
                        Toast.makeText(getActivity(), " ON" +position, Toast.LENGTH_SHORT).show();
                        startAdvertisement(packet);
                    }
                    if(!isChecked){
                        stopAdvertisment(packet.getUniqueId());
                        Toast.makeText(getActivity(), " Off" +position, Toast.LENGTH_SHORT).show();
                    }
                    Log.v(TAG, ""+isChecked);
                }
            });

                return  convertView;
        }



    }
}
