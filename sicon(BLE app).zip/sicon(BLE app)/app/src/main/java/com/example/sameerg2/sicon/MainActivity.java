package com.example.sameerg2.sicon;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.util.Log;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    private final static String TAG = MainActivity.class.getSimpleName();
    private FragmentManager FragManager;
    private String previousTag=null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getPermissions();

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        if (savedInstanceState==null) {
            FragManager = getSupportFragmentManager();
            FragManager.beginTransaction().add(R.id.content, new ScannerFragment(), getString(R.string.ScannerTag)).commit();
            previousTag = getString(R.string.ScannerTag);
        }
    }

    private void getPermissions(){
        //taking permission
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION},1);
        }
        if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},2);
        }
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            Toast.makeText(this, R.string.ble_not_supported, Toast.LENGTH_SHORT).show();
            finish();
        }

    }



    private void changeFragment(String currentTag){

        if(FragManager.findFragmentByTag(previousTag)!=null) {
            FragManager.beginTransaction().hide(FragManager.findFragmentByTag(previousTag)).commit();
        }

        Fragment fragment = FragManager.findFragmentByTag(currentTag);
        if(fragment!=null) {
            FragManager.beginTransaction().show(fragment).commit();
        }
        else {
            FragManager.beginTransaction().add(R.id.content,getFragmentByTag(currentTag),currentTag).commit();
        }

        previousTag = currentTag;

    }

    @Nullable
    private Fragment getFragmentByTag(String currentTag){

        if (currentTag.equalsIgnoreCase(getString(R.string.ScannerTag)))
            return new ScannerFragment();
        if (currentTag.equalsIgnoreCase(getString(R.string.BondedTag)))
            return new BondedFragment();
        if (currentTag.equalsIgnoreCase(getString(R.string.AdvertiseTag)))
            return new AdvertiseFragment();
        if (currentTag.equalsIgnoreCase(getString(R.string.GattTag)))
            return new GattFragment();

        return null;
    }



    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_scanner:
                    changeFragment(getString(R.string.ScannerTag));
                    return true;

                case R.id.navigation_bonded:
                    changeFragment(getString(R.string.BondedTag));
                    return true;

                case R.id.navigation_advertiser:
                    changeFragment(getString(R.string.AdvertiseTag));
                    return true;

                case R.id.navigation_gattserver:
                    changeFragment(getString(R.string.GattTag));
                    return true;

            }
            return false;
        }

    };





}
