package com.example.sameerg2.sicon;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.support.annotation.IdRes;
import android.support.v4.app.DialogFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.RadioGroup;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Date;

/**
 * Created by k.pareek on 4/20/2017.
 */

public class FilterFragment extends DialogFragment {


    private static final String TAG = FilterFragment.class.getSimpleName();
    public static  final String EXTRA_SERVICE="com.example.kpareek.ble_client.SERVICE";
    public static  final String EXTRA_RSSI="com.example.kpareek.ble_client.RSSI";
    public static final  String EXTRA_POWER = "com.example.kpareek.ble_client.POWER";
    private int mPower;
    private int mRssi;
    private String mService;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {

        mService = getArguments().getString(EXTRA_SERVICE);
        mPower   = getArguments().getInt(EXTRA_POWER);
        mRssi    = getArguments().getInt(EXTRA_RSSI);

        View v = getActivity().getLayoutInflater().inflate(R.layout.filter_layout,null);
        Spinner dynamicSpinner = (Spinner) v.findViewById(R.id.spinner);

        RadioGroup grp1 = (RadioGroup) v.findViewById(R.id.radio);
        RadioGroup grp2 = (RadioGroup) v.findViewById(R.id.radio1);
        setListner(grp1);
        setListner(grp2);
        ArrayList<String> items = ServicesCharacterstics.getInstance().getService();

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item, items);
        dynamicSpinner.setAdapter(adapter);
        dynamicSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                Log.v("item", (String) parent.getItemAtPosition(position));
                mService = (String) parent.getItemAtPosition(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // TODO Auto-generated method stub
            }
        });



        return new AlertDialog.Builder(getActivity()).setView(v).setTitle(R.string.filter)
                .setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        System.out.println("Dialoge reached");
                        sendResult(Activity.RESULT_OK);
                    }
                }).create();

    }

    public void  setListner(RadioGroup grp)
    {
         grp.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
             @Override
             public void onCheckedChanged(RadioGroup group, @IdRes int checkedId) {
                 if(checkedId==R.id.low)
                 {
                     mPower = 0;

                 }else if(checkedId==R.id.medium)
                 {
                     mPower = 1;

                 }else if(checkedId==R.id.high){
                     mPower = 2;

                 }
                 else if(checkedId==R.id.low1) {
                     mRssi=0;
                 }
                 else if(checkedId==R.id.medium1){
                     mRssi=1;
                 }else {
                     mRssi=2;
                 }


             }
         });
    }
    public static FilterFragment newInstance(String service,int rssi,int power) {

        Bundle args = new Bundle();
        args.putString(EXTRA_SERVICE,service);
        args.putInt(EXTRA_POWER,power);
        args.putInt(EXTRA_RSSI,rssi);
        FilterFragment fragment = new FilterFragment();
        fragment.setArguments(args);
        return fragment;
    }

    private void sendResult(int resultCode)
    {
        if(getTargetFragment()==null)
            return;
        Intent intent = new Intent();
        Log.d(TAG,""+mRssi+" "+mService+" "+mPower);
        intent.putExtra(EXTRA_SERVICE,mService);
        intent.putExtra(EXTRA_RSSI,mRssi);
        intent.putExtra(EXTRA_POWER,mPower);
        getTargetFragment().onActivityResult(getTargetRequestCode(),resultCode,intent);
    }
}
