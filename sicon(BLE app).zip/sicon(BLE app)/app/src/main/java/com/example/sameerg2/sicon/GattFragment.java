package com.example.sameerg2.sicon;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.List;


public class GattFragment extends Fragment {

    String TAG = "GF";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        /**
         * Inflate the layout for this fragment
         */
        Log.d(TAG,"oncv");
        setRetainInstance(true);
        FrameLayout rootView = (FrameLayout)inflater.inflate(R.layout.fragment_gatt, container, false);

        // recheck implementation
       // FragmentManager FragManager = MainActivity.FragManager;



        Spinner GattServiceSpinner = (Spinner) rootView.findViewById(R.id.spinner_Gattprofiles);

        GattServiceSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {

                String profile = parent.getItemAtPosition(position).toString();

                switch (profile){
                    case "Choose GATT Profile":
                    case "Proximity Profile":


                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }

        });




        return rootView;


    }
}

