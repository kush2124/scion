package com.example.sameerg2.sicon;

import android.app.Service;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothProfile;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.util.Log;

import java.util.List;
import java.util.UUID;

/**
 * Created by k.pareek on 4/4/2017.
 */

@RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)

public class BluetoothLeService extends Service {

    private static final String TAG = BluetoothLeService.class.getSimpleName();
    private int mConnectionState = STATE_DISCONNECTED;
    private boolean serviceDiscovered = false;

    private static final int STATE_DISCONNECTED = 0;
    private static final int STATE_CONNECTING = 1;
    private static final int STATE_CONNECTED = 2;


    public final static String ACTION_GATT_CONNECTED =
            "com.example.kpareek.ble_client.ACTION_GATT_CONNECTED";
    public final static String ACTION_GATT_DISCONNECTED =
            "com.example.kpareek.ble_client.ACTION_GATT_DISCONNECTED";
    public final static String ACTION_GATT_SERVICES_DISCOVERED =
            "com.example.kpareek.ble_client.ACTION_GATT_SERVICES_DISCOVERED";
    public final static String ACTION_DATA_AVAILABLE =
            "com.example.kpareek.ble_client.ACTION_DATA_AVAILABLE";
    public final static String ACTION_DATA_CHANGED =
            "com.example.kpareek.ble_client.ACTION_DATA_CHANGED";
    public final static String EXTRA_DATA =
            "com.example.kpareek.ble_client.EXTRA_DATA";


    private final IBinder mBinder = new LeBinder();
    private BluetoothGatt mGatt;
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return mBinder;
    }

    public class LeBinder extends Binder{
        BluetoothLeService getService()
        {
            return BluetoothLeService.this;
        }
    }


    public void connect(BluetoothDevice device)
    {
        Log.i(TAG,"ConnectGatt called");
        mGatt = device.connectGatt(getApplicationContext(),false,mCallBack);
    }

    public void disconnect()
    {
        if(mGatt!=null)
        {
            mGatt.disconnect();
            mGatt=null;
        }
    }


    public List<BluetoothGattService> getSupportedServices()
    {
        if(mGatt!=null && serviceDiscovered==true) {
            return mGatt.getServices();

        }

        return null;
    }

    private BluetoothGattCallback mCallBack = new BluetoothGattCallback() {


        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            super.onConnectionStateChange(gatt, status, newState);
            Log.i(TAG,"Inside Gatt Callback");
            String intentAction;

            switch (newState)
            {
                case BluetoothProfile.STATE_CONNECTED:
                    intentAction =ACTION_GATT_CONNECTED;
                    broadcastUpdate(intentAction);
                    mConnectionState= STATE_CONNECTED;
                    Log.i(TAG,"state "+mConnectionState);
                    mGatt.discoverServices();
                    break;
                case BluetoothProfile.STATE_DISCONNECTED:
                    serviceDiscovered=false;
                    intentAction = ACTION_GATT_DISCONNECTED;
                    broadcastUpdate(intentAction);
                    mConnectionState=STATE_DISCONNECTED;
                    Log.e(TAG,"state "+mConnectionState);

            }
        }


        @Override
        // New services discovered
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                serviceDiscovered=true;
                broadcastUpdate(ACTION_GATT_SERVICES_DISCOVERED);
            } else {
                Log.w(TAG, "onServicesDiscovered received: " + status);
            }
        }

        @Override
        // Result of a characteristic read operation
        public void onCharacteristicRead(BluetoothGatt gatt,
                                         BluetoothGattCharacteristic characteristic,
                                         int status) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                Log.i(TAG,"Characterstic Read Complete");
                broadcastUpdate(ACTION_DATA_AVAILABLE, characteristic);
            }
        }

        @Override
        public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic) {
            super.onCharacteristicChanged(gatt, characteristic);

                Log.i(TAG,"Notification recieved");
                Log.i(TAG,characteristic.toString());
                broadcastUpdate(ACTION_DATA_CHANGED, characteristic);

        }
    };





    public void readData(BluetoothGattCharacteristic charer)
    {
        Log.i(TAG,"ReadCharacterstic called");
        if(mGatt!=null) {
            boolean retrunValue = mGatt.readCharacteristic(charer);
            Log.i("Return",retrunValue+"--");
        }
        else
        {
            Log.e(TAG,"mGATT is null ");
        }
    }

    private void broadcastUpdate(String action)
    {
        final Intent intent = new Intent(action);
        sendBroadcast(intent);
    }

    public void enableNotification(BluetoothGattCharacteristic characteristic,boolean val)
    {
        if(mGatt!=null) {
            mGatt.setCharacteristicNotification(characteristic, val);
            Log.d("notification","Enabled");
        }
        UUID uuid = characteristic.getUuid();
        BluetoothGattDescriptor descriptor = characteristic.getDescriptor(uuid);
        if(descriptor!=null) {
            descriptor.setValue(BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE);
            mGatt.writeDescriptor(descriptor);
        }
    }


    private void broadcastUpdate(String action ,BluetoothGattCharacteristic characteristic)
    {
        Log.d("Broadcast","insideBroadcast");
        Intent intent = new Intent(action);
        String extradata = ProfileData.getProfileData(characteristic);
        Log.d("Broadcast",extradata);
        intent.putExtra(EXTRA_DATA,extradata);
        sendBroadcast(intent);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.d(TAG,"ServiceDestroyed");
    }
}

