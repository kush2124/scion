package com.example.sameerg2.sicon;

import android.bluetooth.BluetoothDevice;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.util.Log;

/**
 * Created by k.pareek on 3/31/2017.
 */

public class ServiceDisplay extends SingleFragmentActivity {



    private static final String TAG = ServiceDisplay.class.getSimpleName();
    public static final String DEVICE="com.example.kpareek.ble_client.EXTRA_DEVCIE";
    private BluetoothDevice device;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN_MR2)
    @Override
    public Fragment createFragment() {
        return ServiceFragment.newInstance(device);
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {

        device = (BluetoothDevice) ( getIntent().getParcelableExtra(DEVICE));
        Log.d(TAG,device.getAddress());
        super.onCreate(savedInstanceState);

    }


}
