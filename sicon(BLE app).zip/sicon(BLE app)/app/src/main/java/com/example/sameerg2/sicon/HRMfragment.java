package com.example.sameerg2.sicon;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

/**
 * Created by sameer.g2 on 01-May-17.
 */

public class HRMfragment extends Fragment{

        /*String TAG = "HRMfrag";

        @Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
            /**
             * Inflate the layout for this fragment
             */
            //Log.d(TAG,"oncv");
            //setRetainInstance(true);
            //return inflater.inflate(R.layout.fragment_bonded, container, false);
        //}
    }
