package com.example.sameerg2.sicon;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * Created by k.pareek on 4/24/2017.
 */

public class ServicesCharacterstics {

    private static ArrayList<String> services;
    private static HashMap<String,String> serviceUUID;
    private static HashMap<String,String>serviceFromUUID;
    private static HashMap<String,String>  characteristicsFromUuid;
    private static HashMap<String,String>  characteristics;
    private static ServicesCharacterstics sInst;
    public static  ServicesCharacterstics getInstance()
    {
        if(sInst==null)
           sInst =  new ServicesCharacterstics();

        return sInst;
    }

    private ServicesCharacterstics()
    {
        fillServices();
        fillCharacterstics();
    }
    private void fillServices()
    {
         services =  new ArrayList<String>();
         serviceUUID = new HashMap<String,String>();
         serviceFromUUID = new HashMap<String,String>();

         services.add("HRM");
         serviceUUID.put("HRM", "0000180D-0000-1000-8000-00805F9B34FB");
         services.add("ALL");
         serviceUUID.put("ALL", null);

         serviceFromUUID.put("0000180D-0000-1000-8000-00805F9B34FB","HRM");
         serviceFromUUID.put("00001801-0000-1000-8000-00805F9B34FB","Genric Attribute");
         serviceFromUUID.put("00001800-0000-1000-8000-00805F9B34FB","Generic Access");

    }
    private void fillCharacterstics()
    {
        characteristics = new HashMap<String,String>();
        characteristics.put("Device Name","00002A00-0000-1000-8000-00805F9B34FB");
        characteristics.put("Appereance","00002A01-0000-1000-8000-00805F9B34FB");
        characteristics.put("Peripheral Privacy Flag","00002A02-0000-1000-8000-00805F9B34FB");
        characteristics.put("Reconnection Address","00002A03-0000-1000-8000-00805F9B34FB");
        characteristics.put("Service Changed","00002A05-0000-1000-8000-00805F9B34FB");
        characteristics.put("Central Address Resolution","00002AA6-0000-1000-8000-00805F9B34FB");
        characteristics.put("Heart Rate Measurment","00002A37-0000-1000-8000-00805F9B34FB");

        characteristicsFromUuid = new HashMap<String,String>();
        characteristicsFromUuid.put("00002A00-0000-1000-8000-00805F9B34FB","Device Name");
        characteristicsFromUuid.put("00002A01-0000-1000-8000-00805F9B34FB","Appereance");
        characteristicsFromUuid.put("00002A02-0000-1000-8000-00805F9B34FB","Peripheral Privacy Flag");
        characteristicsFromUuid.put("00002A03-0000-1000-8000-00805F9B34FB","Reconnection Address");
        characteristicsFromUuid.put("00002A05-0000-1000-8000-00805F9B34FB","Service Changed");
        characteristicsFromUuid.put("00002AA6-0000-1000-8000-00805F9B34FB","Central Address Resolution");
        characteristicsFromUuid.put("00002A37-0000-1000-8000-00805F9B34FB","Heart Rate Measurment");


    }
    public ArrayList<String> getService()
    {
        fillServices();
        return services;
    }

    public String getServiceUUID(String serviceName)
    {
        return serviceUUID.get(serviceName);
    }

    public String getServiceFromUUID(String Uuid)
    {
        return serviceFromUUID.get(Uuid);
    }

    public String getcharFromUuid(String uuid)
    {
       return characteristicsFromUuid.get(uuid);
    }

    public String getUidFromCharacterstics(String name){
        return characteristics.get(name);
    }

}
