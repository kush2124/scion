package com.example.sameerg2.sicon;



/**
 * Created by sameer.g2 on 27-Apr-17.
 */

public class AdvertisementPacket {

    private String displayName,serviceUuid,serviceData;
    private Boolean connectable,localName;
    private int advMode, advPower,timeout;
    private Integer uniqueId;


    AdvertisementPacket(String dname, String suuid, String sdata, Boolean Lname,
                        Boolean Conn, int AdvModeint, int AdvPowerint, int uid, int time){

        displayName = dname;
        serviceUuid = suuid;
        serviceData = sdata;
        localName = Lname;
        connectable = Conn;
        advMode = AdvModeint;
        advPower = AdvPowerint;
         uniqueId = uid;
        timeout = time;
    }


    public Integer getUniqueId()
    {
      return uniqueId;
    }

    public String getDisplayName()
    {
        return displayName;
    }

    public String getServiceUuid()
    {
        return serviceUuid;
    }

    public String getServiceData()
    {
        return serviceData;
    }

    public Boolean getConnectable()
    {
        return connectable;
    }

    public Boolean getLocalName()
    {
        return localName;
    }

    public int getAdvMode()
    {
        return advMode;
    }

    public int getAdvPower()
    {
        return advPower;
    }

    public int getTimeout()
    {
        return  timeout;
    }

}