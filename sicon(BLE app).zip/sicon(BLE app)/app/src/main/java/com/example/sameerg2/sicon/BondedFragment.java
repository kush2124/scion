package com.example.sameerg2.sicon;


import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Set;

/**
 * Created by k.pareek on 5/1/2017.
 */

public class BondedFragment extends android.support.v4.app.ListFragment {

    private static final String TAG = BondedFragment.class.getSimpleName();
    private BluetoothAdapter mAdapter = BluetoothAdapter. getDefaultAdapter();
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

          Set<BluetoothDevice> bonded = mAdapter.getBondedDevices();
          ArrayList<BluetoothDevice> mBonded = new ArrayList<BluetoothDevice>(bonded);
          BondedAdapter adapter = new BondedAdapter(mBonded);
          setListAdapter(adapter);
    }


    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        BluetoothDevice device = (BluetoothDevice) getListAdapter().getItem(position);

        Intent intent = new Intent(getActivity(), ServiceDisplay.class);
        intent.putExtra(ServiceDisplay.DEVICE, device);
        startActivity(intent);

    }

    private class BondedAdapter extends ArrayAdapter<BluetoothDevice>{


        public BondedAdapter(ArrayList<BluetoothDevice> bonded) {
            super(getActivity(),0,bonded);

        }


        @NonNull
        @Override

        public View getView(int position, View convertView, ViewGroup parent)
            {
                ViewHolder holder;
                if(convertView==null)
                {
                    convertView = getActivity().getLayoutInflater().inflate(R.layout.le_devices,null);
                    TextView nameTextView =  (TextView)convertView.findViewById(R.id.device_name);
                    TextView addTextView = (TextView) convertView.findViewById(R.id.device_add);

                    holder = new ViewHolder(nameTextView,addTextView);
                    convertView.setTag(holder);
                }


                holder = (ViewHolder) convertView.getTag();
                BluetoothDevice device = getItem(position);
                if(device.getName()!=null)
                    holder.getNameTextView().setText(device.getName());
                else
                    holder.getNameTextView().setText(getResources().getString(R.string.unknown_device));

                    holder.getAddTextView().setText(device.getAddress());

                return  convertView;
            }


    }
}
